package com.cognizant.main.ServiceTest;

import com.cognizant.dto.NomineeRelationsDTO;
import com.cognizant.entity.NomineeRelations;
import com.cognizant.repositories.NomineeRelationsRepository;
import com.cognizant.service.NomineeRelationsServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

class TestNomineeRelationsServiceImpl {

    @Mock
    NomineeRelationsRepository nomineeRelationsRepository;





    @InjectMocks
    NomineeRelationsServiceImpl nomineeRelationsServiceImpl;



    @BeforeEach
     void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @AfterEach
     void tearDown() throws Exception {

    }

    @Test
    void getAllNomineeTypes() {
        try {

            NomineeRelations nomineeRelations = new NomineeRelations();
            nomineeRelations.setType(1);
            ArrayList<NomineeRelations> listOfNomineeRelations = new ArrayList<NomineeRelations>();
            listOfNomineeRelations.add(nomineeRelations);
            when(nomineeRelationsRepository.findAll()).thenReturn(listOfNomineeRelations);

            List<NomineeRelationsDTO> result = nomineeRelationsServiceImpl.getAllNomineeTypes();

            assertEquals(1, result.size());
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }


    }
}