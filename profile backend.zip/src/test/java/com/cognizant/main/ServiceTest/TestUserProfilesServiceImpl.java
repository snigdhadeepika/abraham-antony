package com.cognizant.main.ServiceTest;

import com.cognizant.dto.UserProfilesDTO;
import com.cognizant.entity.UserProfiles;

import com.cognizant.mappers.UserProfilesMapper;
import com.cognizant.repositories.UserProfilesRepository;
import com.cognizant.service.UserProfilesServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.sql.SQLException;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

class TestUserProfilesServiceImpl {
    @Mock
    UserProfilesRepository userProfilesRepository;

    @InjectMocks
    UserProfilesServiceImpl userProfilesServiceImpl;

    @BeforeEach
     void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @AfterEach
    void tearDown() throws Exception {

    }

    @Test
    void addUserProfiles_Positive() {
        try {
            UserProfiles userProfiles = new UserProfiles();

            UserProfilesDTO userProfilesDTO = new UserProfilesDTO();
            userProfilesDTO.setUsername("abanto1234");
            userProfilesDTO.setFirstName("Abraham");
            userProfilesDTO.setMiddleName("k");
            userProfilesDTO.setLastName("antony");
            userProfilesDTO.setDateOfBirth(LocalDate.now());
            userProfilesDTO.setGender('M');
            userProfilesDTO.setProfession("SDE");
            userProfilesDTO.setCurrentAddress("Pune");
            userProfilesDTO.setNationality("Indian");
            userProfilesDTO.setIdProofType("Passport");
            userProfilesDTO.setIdProofDocNumber("3231");
            userProfilesDTO.setPhoneNumber("1234567890");
            userProfilesDTO.setEmailAddress("abru@123");


            userProfiles.setUsername("abanto1234");
            userProfiles.setFirstName("Abraham");
            userProfiles.setMiddleName("k");
            userProfiles.setLastName("antony");
            userProfiles.setDateOfBirth(LocalDate.now());
            userProfiles.setGender('M');
            userProfiles.setProfession("SDE");
            userProfiles.setCurrentAddress("Pune");
            userProfiles.setNationality("Indian");
            userProfiles.setIdProofType("Passport");
            userProfiles.setIdProofDocNumber("3231");
            userProfiles.setPhoneNumber("1234567890");

            when(userProfilesRepository.save(any(UserProfiles.class))).thenReturn(userProfiles);

            String userName=userProfilesServiceImpl.addUserProfile(userProfilesDTO);
            assertEquals("abanto1234",userName);

        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

        @Test
        void addUserProfiles_Negative(){
            try {
                UserProfiles userProfiles = new UserProfiles();

                UserProfilesDTO userProfilesDTO = new UserProfilesDTO();
                userProfilesDTO.setUsername("abanto1234");
                userProfilesDTO.setFirstName("Abraham");
                userProfilesDTO.setMiddleName("k");
                userProfilesDTO.setLastName("antony");
                userProfilesDTO.setDateOfBirth(LocalDate.now());
                userProfilesDTO.setGender('M');
                userProfilesDTO.setProfession("SDE");
                userProfilesDTO.setCurrentAddress("Pune");
                userProfilesDTO.setNationality("Algerian");
                userProfilesDTO.setIdProofType("Aadhar");
                userProfilesDTO.setIdProofDocNumber("3231");
                userProfilesDTO.setPhoneNumber("1234567890");
                userProfilesDTO.setEmailAddress("abru@123");

                String userName=userProfilesServiceImpl.addUserProfile(userProfilesDTO);


            } catch (Exception e) {

                assertEquals("If nationality is other than Indian Passport is only accepted", e.getMessage());
                assertTrue(true);
            }
        }


    @Test
    void addUserProfiles_Positive2() {
        try {
            UserProfiles userProfiles = new UserProfiles();

            UserProfilesDTO userProfilesDTO = new UserProfilesDTO();
            userProfilesDTO.setUsername("abanto1234");
            userProfilesDTO.setFirstName("Abraham");
            userProfilesDTO.setMiddleName("k");
            userProfilesDTO.setLastName("antony");
            userProfilesDTO.setDateOfBirth(LocalDate.now());
            userProfilesDTO.setGender('M');
            userProfilesDTO.setProfession("SDE");
            userProfilesDTO.setCurrentAddress("Pune");
            userProfilesDTO.setNationality("Indian");
            userProfilesDTO.setIdProofType("PAN");
            userProfilesDTO.setIdProofDocNumber("3231");
            userProfilesDTO.setPhoneNumber("1234567890");
            userProfilesDTO.setEmailAddress("abru@123");


            userProfiles.setUsername("abanto1234");
            userProfiles.setFirstName("Abraham");
            userProfiles.setMiddleName("k");
            userProfiles.setLastName("antony");
            userProfiles.setDateOfBirth(LocalDate.now());
            userProfiles.setGender('M');
            userProfiles.setProfession("SDE");
            userProfiles.setCurrentAddress("Pune");
            userProfiles.setNationality("Indian");
            userProfiles.setIdProofType("Passport");
            userProfiles.setIdProofDocNumber("3231");
            userProfiles.setPhoneNumber("1234567890");

            when(userProfilesRepository.save(any(UserProfiles.class))).thenReturn(userProfiles);

            String userName=userProfilesServiceImpl.addUserProfile(userProfilesDTO);
            assertEquals("abanto1234",userName);

        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }





}