package com.cognizant.main.ServiceTest;

import com.cognizant.dto.NomineeRelationsDTO;
import com.cognizant.dto.UserNomineesDTO;
import com.cognizant.entity.NomineeRelations;
import com.cognizant.entity.UserNominees;
import com.cognizant.entity.UserProfiles;
import com.cognizant.mappers.UserNomineesMapper;
import com.cognizant.repositories.NomineeRelationsRepository;
import com.cognizant.repositories.UserNomineesRepository;
import com.cognizant.repositories.UserProfilesRepository;
import com.cognizant.service.UserNomineesServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

 class TestUserNomineesServiceImpl {


    @Mock
    UserNomineesRepository userNomineesRepository;

    @InjectMocks
    UserNomineesServiceImpl userNomineesServiceImpl;

    @Mock
    UserProfilesRepository userProfilesRepository;

    @Mock
    NomineeRelationsRepository nomineeRelationsRepository;


    @BeforeEach
     void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @AfterEach
     void tearDown() throws Exception {

    }

    @Test
    void testGetNomineeDetails_Positive() {
        try {
            String username = "abanto1234";
            NomineeRelations nomineeRelations = new NomineeRelations();
            nomineeRelations.setType(1);
            nomineeRelations.setNomineeRelationsId(1);
            UserProfiles userProfiles = new UserProfiles();
            UserNominees userNominees = new UserNominees();
            userNominees.setNomineeRelations(nomineeRelations);
            userNominees.setFullName("Paul Antony");
            UserNomineesDTO expectedUserNomineesDTO = new UserNomineesDTO();
            expectedUserNomineesDTO.setFullName("Paul Antony");

            when(userProfilesRepository.findById(username)).thenReturn(Optional.of(userProfiles));
            when(userNomineesRepository.findByUserProfiles(userProfiles)).thenReturn(userNominees);


            UserNomineesDTO actualUserNomineesDTO = userNomineesServiceImpl.getNomineeDetails(username);

            assertEquals(expectedUserNomineesDTO.getFullName(), actualUserNomineesDTO.getFullName());


        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    void testGetNomineeDetails_Negative() {
        try {
            String username = "abanto1234";
            NomineeRelations nomineeRelations = new NomineeRelations();
            nomineeRelations.setType(1);
            nomineeRelations.setNomineeRelationsId(1);
            UserProfiles userProfiles = new UserProfiles();
            UserNominees userNominees = new UserNominees();
            userNominees.setNomineeRelations(nomineeRelations);
            userNominees.setFullName("Paul Antony");
            UserNomineesDTO expectedUserNomineesDTO = new UserNomineesDTO();
            expectedUserNomineesDTO.setFullName("Paul Antony");

            when(userProfilesRepository.findById(username)).thenReturn(Optional.empty());
            when(userNomineesRepository.findByUserProfiles(userProfiles)).thenReturn(userNominees);


            UserNomineesDTO actualUserNomineesDTO = userNomineesServiceImpl.getNomineeDetails(username);

            assertEquals(null, actualUserNomineesDTO.getFullName());


        } catch (Exception e) {
            assertTrue(true);
        }
    }

    @Test
    void testGetNomineeDetails_Exception() {
        try {
            String username = "abanto1234";
            NomineeRelations nomineeRelations = new NomineeRelations();
            nomineeRelations.setType(1);
            nomineeRelations.setNomineeRelationsId(1);
            UserProfiles userProfiles = new UserProfiles();

            UserNomineesDTO expectedUserNomineesDTO = new UserNomineesDTO();
            expectedUserNomineesDTO.setFullName("Paul Antony");

            when(userProfilesRepository.findById(username)).thenReturn(Optional.of(userProfiles));
            when(userNomineesRepository.findByUserProfiles(userProfiles)).thenReturn(null);


            UserNomineesDTO actualUserNomineesDTO = userNomineesServiceImpl.getNomineeDetails(username);

            assertEquals(null, actualUserNomineesDTO.getFullName());


        } catch (Exception e) {

            assertTrue(true);
        }
    }


    @Test
    void testRemoveNomineeDetails_Positive() {
        try {
            String username = "abanto1234";
            UserProfiles userProfiles = new UserProfiles();
            userProfiles.setUsername("abanto1234");
            UserNominees userNominees = new UserNominees();
            userNominees.setId(1);

            when(userProfilesRepository.findById(username)).thenReturn(Optional.of(userProfiles));
            when(userNomineesRepository.findByUserProfiles(userProfiles)).thenReturn(userNominees);
            doNothing().when(userNomineesRepository).delete(userNominees);
            when(userNomineesRepository.findById(userNominees.getId())).thenReturn(Optional.empty());

            String result = userNomineesServiceImpl.removeNomineeDetails(username);

            assertEquals("success", result);


        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }


    @Test
    void testRemoveNomineeDetails_Negative() {
        try {
            String username = "abanto1234";
            UserProfiles userProfiles = new UserProfiles();
            userProfiles.setUsername("abanto1234");
            UserNominees userNominees = new UserNominees();
            userNominees.setId(1);

            when(userProfilesRepository.findById(username)).thenReturn(Optional.empty());
            when(userNomineesRepository.findByUserProfiles(userProfiles)).thenReturn(userNominees);
            doNothing().when(userNomineesRepository).delete(userNominees);
            when(userNomineesRepository.findById(userNominees.getId())).thenReturn(Optional.empty());

            String result = userNomineesServiceImpl.removeNomineeDetails(username);

            assertEquals("failure", result);


        } catch (Exception e) {
            assertTrue(true);
        }
    }

    @Test
    void testRemoveNomineeDetails_Exception() {
        try {
            String username = "abanto1234";
            UserProfiles userProfiles = new UserProfiles();
            userProfiles.setUsername("abanto1234");
            UserNominees userNominees = new UserNominees();
            userNominees.setId(1);

            when(userProfilesRepository.findById(username)).thenReturn(Optional.of(userProfiles));
            when(userNomineesRepository.findByUserProfiles(userProfiles)).thenReturn(userNominees);
            doNothing().when(userNomineesRepository).delete(userNominees);
            when(userNomineesRepository.findById(userNominees.getId())).thenReturn(Optional.of(userNominees));

            String result = userNomineesServiceImpl.removeNomineeDetails(username);

            assertEquals("failure", result);


        } catch (Exception e) {

            assertTrue(true);
        }
    }

    @Test
    void addNomineeDetails_Positive() {
        try {
            String userName = "abanto1234";

            NomineeRelations nomineeRelations = new NomineeRelations();
            nomineeRelations.setType(1);

            UserNominees userNominees = new UserNominees();
            userNominees.setFullName("Paul Antony");

            UserNomineesDTO userNomineesDTO = new UserNomineesDTO();
            userNomineesDTO.setFullName("Paul Antony");
            userNomineesDTO.setNationality("Indian");
            userNomineesDTO.setIdProofType("Passport");
            userNomineesDTO.setNomineeRelationType(NomineeRelationsDTO.NomineeRelationType.Child);
            UserProfiles userProfiles = new UserProfiles();
            userProfiles.setUsername(userName);
            when(userProfilesRepository.findById(userName)).thenReturn(Optional.of(userProfiles));
            when(userNomineesRepository.findByUserProfiles(userProfiles)).thenReturn(null);

            when(nomineeRelationsRepository.findByType(1)).thenReturn(nomineeRelations);
            when(userNomineesRepository.save(any(UserNominees.class))).thenReturn(userNominees);
            String actual = userNomineesServiceImpl.addNomineeDetails(userNomineesDTO, userName);
            assertEquals("success", actual);
        } catch (Exception e) {
            assertTrue(false);
        }
    }


    @Test
    void addNomineeDetails_Negative() {
        try {
            String userName = "abanto1234";

            NomineeRelations nomineeRelations = new NomineeRelations();
            nomineeRelations.setType(1);

            UserNominees userNominees = new UserNominees();
            userNominees.setFullName("Paul Antony");

            UserNomineesDTO userNomineesDTO = new UserNomineesDTO();
            userNomineesDTO.setFullName("Paul Antony");
            userNomineesDTO.setNationality("Indian");
            userNomineesDTO.setIdProofType("Passport");
            userNomineesDTO.setNomineeRelationType(NomineeRelationsDTO.NomineeRelationType.Child);
            UserProfiles userProfiles = new UserProfiles();
            userProfiles.setUsername(userName);
            when(userProfilesRepository.findById(userName)).thenReturn(Optional.of(userProfiles));
            when(userNomineesRepository.findByUserProfiles(userProfiles)).thenReturn(null);

            when(nomineeRelationsRepository.findByType(1)).thenReturn(nomineeRelations);
            when(userNomineesRepository.save(any(UserNominees.class))).thenReturn(null);
            String actual = userNomineesServiceImpl.addNomineeDetails(userNomineesDTO, userName);
            assertEquals("failure", actual);
        } catch (Exception e) {
            assertTrue(true);
        }
    }

    @Test
    void addNomineeDetails_IDProofTypeException() {
        try {
            String userName = "abanto1234";

            NomineeRelations nomineeRelations = new NomineeRelations();
            nomineeRelations.setType(1);

            UserNominees userNominees = new UserNominees();
            userNominees.setFullName("Paul Antony");

            UserNomineesDTO userNomineesDTO = new UserNomineesDTO();
            userNomineesDTO.setFullName("Paul Antony");
            userNomineesDTO.setNationality("Algerian");
            userNomineesDTO.setIdProofType("Aadhar");
            userNomineesDTO.setNomineeRelationType(NomineeRelationsDTO.NomineeRelationType.Child);
            UserProfiles userProfiles = new UserProfiles();
            userProfiles.setUsername(userName);
            when(userProfilesRepository.findById(userName)).thenReturn(Optional.of(userProfiles));
            when(userNomineesRepository.findByUserProfiles(userProfiles)).thenReturn(null);

            when(nomineeRelationsRepository.findByType(1)).thenReturn(nomineeRelations);
            when(userNomineesRepository.save(any(UserNominees.class))).thenReturn(userNominees);
            String actual = userNomineesServiceImpl.addNomineeDetails(userNomineesDTO, userName);
            assertEquals("failure",actual);

        } catch (Exception e) {
            assertEquals( "If nationality is other than Indian Passport is only accepted",e.getMessage());
            assertTrue(true);
        }
    }


    @Test
    void addNomineeDetails_Only1NomineeException()

    {
        {
            try {
                String userName = "abanto1234";

                NomineeRelations nomineeRelations = new NomineeRelations();
                nomineeRelations.setType(1);

                UserNominees userNominees = new UserNominees();
                userNominees.setFullName("Paul Antony");

                UserNomineesDTO userNomineesDTO = new UserNomineesDTO();
                userNomineesDTO.setFullName("Paul Antony");
                userNomineesDTO.setNationality("Indian");
                userNomineesDTO.setIdProofType("Passport");
                userNomineesDTO.setNomineeRelationType(NomineeRelationsDTO.NomineeRelationType.Child);
                UserProfiles userProfiles = new UserProfiles();
                userProfiles.setUsername(userName);
                when(userProfilesRepository.findById(userName)).thenReturn(Optional.of(userProfiles));
                when(userNomineesRepository.findByUserProfiles(userProfiles)).thenReturn(userNominees);

                when(nomineeRelationsRepository.findByType(1)).thenReturn(nomineeRelations);
                when(userNomineesRepository.save(any(UserNominees.class))).thenReturn(userNominees);
                String actual = userNomineesServiceImpl.addNomineeDetails(userNomineesDTO, userName);
                assertEquals("failure",actual);
            } catch (Exception e) {
                assertEquals("One user can have only one Nominee",e.getMessage());
                assertTrue(true);
            }
        }


    }

    @Test
    void addNomineeDetails_Negative2() {
        try {
            String userName = "abanto1234";

            NomineeRelations nomineeRelations = new NomineeRelations();
            nomineeRelations.setType(1);

            UserNominees userNominees = new UserNominees();
            userNominees.setFullName("Paul Antony");

            UserNomineesDTO userNomineesDTO = new UserNomineesDTO();
            userNomineesDTO.setFullName("Paul Antony");
            userNomineesDTO.setNationality("Indian");
            userNomineesDTO.setIdProofType("Passport");
            userNomineesDTO.setNomineeRelationType(NomineeRelationsDTO.NomineeRelationType.Child);
            UserProfiles userProfiles = new UserProfiles();
            userProfiles.setUsername(userName);
            when(userProfilesRepository.findById(userName)).thenReturn(Optional.empty());
            when(userNomineesRepository.findByUserProfiles(userProfiles)).thenReturn(null);

            when(nomineeRelationsRepository.findByType(1)).thenReturn(nomineeRelations);
            when(userNomineesRepository.save(any(UserNominees.class))).thenReturn(userNominees);
            String actual = userNomineesServiceImpl.addNomineeDetails(userNomineesDTO, userName);
            assertEquals("failure", actual);
        } catch (Exception e) {
            assertTrue(false);
        }
    }



}
