package com.cognizant.main.RepositoryTest;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.Optional;

import com.cognizant.repositories.UserProfilesRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import com.cognizant.ProfileManagementApplication;
import com.cognizant.entity.UserNominees;
import com.cognizant.repositories.UserNomineesRepository;

@DataJpaTest
@ContextConfiguration(classes = ProfileManagementApplication.class)
class TestUserNomineesRepository {

	@Autowired
	private UserNomineesRepository userNomineesRepository;

	@Autowired
	private UserProfilesRepository userProfilesRepository;
	@Autowired
	private TestEntityManager entityManager;

	@Test
	void testFindAllPositive() {
		UserNominees userNominees = new UserNominees();
		userNominees.setFullName("abraham");
		userNominees.setDateOfBirth(LocalDate.now());
		userNominees.setGender('M');
		userNominees.setNationality("Indian");
		userNominees.setIdProofType("Passport");
		userNominees.setIdProofDocNumber("3231");
		entityManager.persist(userNominees);
		Iterable<UserNominees> it = userNomineesRepository.findAll();
		assertTrue(it.iterator().hasNext());
	}

	@Test
	 void testFindAllNegative() {
		Iterable<UserNominees> it = userNomineesRepository.findAll();
		assertTrue(!it.iterator().hasNext());

	}

	@Test
	 void testFindByIdPositive() {
		UserNominees u = new UserNominees();
		//u.setId(123);
		u.setFullName("abraham");
		u.setDateOfBirth(LocalDate.now());
		u.setGender('M');
		u.setNationality("Indian");
		u.setIdProofType("Passport");
		u.setIdProofDocNumber("3231");
		int id=entityManager.persist(u).getId();
		Optional<UserNominees> userNominees = userNomineesRepository.findById(id);
		assertTrue(userNominees.isPresent());

	}

	@Test
	void testFindByIdNegative() {
		Optional<UserNominees> userNominees = userNomineesRepository.findById(123);
		assertTrue(!userNominees.isPresent());
	}

	@Test
	 void testSavePositive() {
		UserNominees u = new UserNominees();
		u.setFullName("abraham");
		u.setDateOfBirth(LocalDate.now());
		u.setGender('M');
		u.setNationality("Indian");
		u.setIdProofType("Passport");
		u.setIdProofDocNumber("3231");
		int id=userNomineesRepository.save(u).getId();		
		Optional<UserNominees> userNominees = userNomineesRepository.findById(id);
		assertTrue(userNominees.isPresent());
	}

	@Test
	 void testDeletePositive() {
		UserNominees u = new UserNominees();
		u.setFullName("abraham");
		u.setDateOfBirth(LocalDate.now());
		u.setGender('M');
		u.setNationality("Indian");
		u.setIdProofType("Passport");
		u.setIdProofDocNumber("3231");
		entityManager.persist(u);
		userNomineesRepository.delete(u);
		Optional<UserNominees> userNominees = userNomineesRepository.findById(123);
		assertTrue(!userNominees.isPresent());

	}
	
	@Test
	 void testCountPositive()
	{
		UserNominees u = new UserNominees();
		u.setFullName("abraham");
		u.setDateOfBirth(LocalDate.now());
		u.setGender('M');
		u.setNationality("Indian");
		u.setIdProofType("Passport");
		u.setIdProofDocNumber("3231");
		entityManager.persist(u);
		long expectedCount=1;
		long actualCount=userNomineesRepository.count();
		assertEquals(expectedCount,actualCount);
		
	}


	
	
}
