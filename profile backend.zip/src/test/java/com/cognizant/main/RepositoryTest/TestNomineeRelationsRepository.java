package com.cognizant.main.RepositoryTest;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import com.cognizant.ProfileManagementApplication;
import com.cognizant.entity.NomineeRelations;
import com.cognizant.repositories.NomineeRelationsRepository;

@DataJpaTest
@ContextConfiguration(classes = ProfileManagementApplication.class)
class TestNomineeRelationsRepository {

	@Autowired
	private NomineeRelationsRepository nomineeRelationsRepository;
	@Autowired
	private TestEntityManager entityManager;

	@Test
	 void testFindAllPositive() {
		NomineeRelations nomineeRelations = new NomineeRelations();
		nomineeRelations.setType(100);
		int id=entityManager.persist(nomineeRelations).getNomineeRelationsId();
		Iterable<NomineeRelations> nomineeRelationsIterable = nomineeRelationsRepository.findAll();
		assertTrue(nomineeRelationsIterable.iterator().hasNext());
	}



	@Test
	 void testFindByIdPositive() {
		NomineeRelations nomineeRelations = new NomineeRelations();
		nomineeRelations.setNomineeRelationsId(21);
		nomineeRelations.setType(100);
		int id=entityManager.persist(nomineeRelations).getNomineeRelationsId();
		Optional<NomineeRelations> nomineeRelationsOptional = nomineeRelationsRepository.findById(21);
		assertTrue(nomineeRelationsOptional.isPresent());

	}

	@Test
	 void testFindByIdNegative() {
		Optional<NomineeRelations> nomineeRelations = nomineeRelationsRepository.findById(1001);
		assertTrue(!nomineeRelations.isPresent());
	}

	
	  @Test 
	   void testSavePositive()
	  { 
	  NomineeRelations nomineeRelations = new NomineeRelations();
	  nomineeRelations.setNomineeRelationsId(1001);
	  nomineeRelations.setType(100);
	  int id =nomineeRelationsRepository.save(nomineeRelations).getNomineeRelationsId();
	  Optional<NomineeRelations> nomineeRelationsOptional=nomineeRelationsRepository.findById(id);
	  assertTrue(nomineeRelationsOptional.isPresent());
	  }
	  
	 
	@Test
	 void testDeletePositive() {
		NomineeRelations nomineeRelations = new NomineeRelations();
		nomineeRelations.setNomineeRelationsId(21);
		nomineeRelations.setType(100);
		int id=entityManager.persist(nomineeRelations).getNomineeRelationsId();
		nomineeRelationsRepository.delete(nomineeRelations);
		Optional<NomineeRelations> nomineeRelationsOptional = nomineeRelationsRepository.findById(21);
		assertTrue(!nomineeRelationsOptional.isPresent());

	}
	
	@Test
	 void testCountPositive()
	{
		NomineeRelations nomineeRelations = new NomineeRelations();
		nomineeRelations.setType(100);
		entityManager.persist(nomineeRelations);
		long expectedCount=6;
		long actualCount=nomineeRelationsRepository.count();
		assertEquals(expectedCount,actualCount);
		
	}
	
	
	
	
	
	

}
