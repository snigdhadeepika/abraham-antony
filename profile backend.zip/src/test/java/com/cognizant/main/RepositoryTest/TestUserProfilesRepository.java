package com.cognizant.main.RepositoryTest;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import com.cognizant.ProfileManagementApplication;
import com.cognizant.entity.UserProfiles;
import com.cognizant.repositories.UserProfilesRepository;



@DataJpaTest
@ContextConfiguration(classes = ProfileManagementApplication.class)
class TestUserProfilesRepository {
	
	@Autowired
	private UserProfilesRepository userProfilesRepository;

	@Autowired
	private TestEntityManager entityManager;

	@Test
	 void testFindAllPositive() {
		UserProfiles userProfiles = new UserProfiles();
		userProfiles.setUsername("abraham3");
		userProfiles.setFirstName("abraham");
		userProfiles.setMiddleName("k");
		userProfiles.setLastName("antony");
		userProfiles.setDateOfBirth(LocalDate.now());
		userProfiles.setGender('M');
		userProfiles.setProfession("SDE");
		userProfiles.setCurrentAddress("Pune");
		userProfiles.setNationality("Indian");
		userProfiles.setIdProofType("Passport");
		userProfiles.setIdProofDocNumber("3231");
		userProfiles.setPhoneNumber("1234567890");
		userProfiles.setEmailAddress("abru@123");
		entityManager.persist(userProfiles);
		Iterable<UserProfiles> it = userProfilesRepository.findAll();
		assertTrue(it.iterator().hasNext());
	}

	@Test
	void testFindAllNegative() {
		Iterable<UserProfiles> it = userProfilesRepository.findAll();
		assertTrue(!it.iterator().hasNext());

	}

	@Test
	 void testFindByIdPositive() {
		UserProfiles u = new UserProfiles();
		u.setUsername("abraham3");
		u.setFirstName("abraham");
		u.setMiddleName("k");
		u.setLastName("antony");
		u.setDateOfBirth(LocalDate.now());
		u.setGender('M');
		u.setProfession("SDE");
		u.setCurrentAddress("Pune");
		u.setNationality("Indian");
		u.setIdProofType("Passport");
		u.setIdProofDocNumber("3231");
		u.setPhoneNumber("1234567890");
		u.setEmailAddress("abru@123");
		entityManager.persist(u);		
		Optional<UserProfiles> userProfiles = userProfilesRepository.findById("abraham3");
		assertTrue(userProfiles.isPresent());

	}

	@Test
	 void testFindByIdNegative() {
		Optional<UserProfiles> userProfiles = userProfilesRepository.findById("abraham3");
		assertTrue(!userProfiles.isPresent());
	}

	@Test
	 void testSavePositive() {
		UserProfiles u = new UserProfiles();
		u.setUsername("abraham3");
		u.setFirstName("abraham");
		u.setMiddleName("k");
		u.setLastName("antony");
		u.setDateOfBirth(LocalDate.now());
		u.setGender('M');
		u.setProfession("SDE");
		u.setCurrentAddress("Pune");
		u.setNationality("Indian");
		u.setIdProofType("Passport");
		u.setIdProofDocNumber("3231");
		u.setPhoneNumber("1234567890");
		u.setEmailAddress("abru@123");
		userProfilesRepository.save(u);
		Optional<UserProfiles> userProfiles = userProfilesRepository.findById("abraham3");
		assertTrue(userProfiles.isPresent());
	}

	@Test
	 void testDeletePositive() {
		UserProfiles u = new UserProfiles();
		u.setUsername("abraham3");
		u.setFirstName("abraham");
		u.setMiddleName("k");
		u.setLastName("antony");
		u.setDateOfBirth(LocalDate.now());
		u.setGender('M');
		u.setProfession("SDE");
		u.setCurrentAddress("Pune");
		u.setNationality("Indian");
		u.setIdProofType("Passport");
		u.setIdProofDocNumber("3231");
		u.setPhoneNumber("1234567890");
		u.setEmailAddress("abru@123");
		entityManager.persist(u);
		userProfilesRepository.delete(u);
		Optional<UserProfiles> userProfiles = userProfilesRepository.findById("abraham3");
		assertTrue(!userProfiles.isPresent());

	}
	
	@Test
	 void testCountPositive()
	{
		UserProfiles u = new UserProfiles();
		u.setUsername("abraham3");
		u.setFirstName("abraham");
		u.setMiddleName("k");
		u.setLastName("antony");
		u.setDateOfBirth(LocalDate.now());
		u.setGender('M');
		u.setProfession("SDE");
		u.setCurrentAddress("Pune");
		u.setNationality("Indian");
		u.setIdProofType("Passport");
		u.setIdProofDocNumber("3231");
		u.setPhoneNumber("1234567890");
		u.setEmailAddress("abru@123");
		entityManager.persist(u);
		long expectedCount=1;
		long actualCount=userProfilesRepository.count();
		assertEquals(expectedCount,actualCount);
		
	}
	
	

}
