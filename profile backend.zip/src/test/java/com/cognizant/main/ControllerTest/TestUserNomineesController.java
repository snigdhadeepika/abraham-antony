package com.cognizant.main.ControllerTest;

import com.cognizant.controller.UserNomineesController;
import com.cognizant.dto.UserNomineesDTO;
import com.cognizant.entity.UserNominees;
import com.cognizant.exception.IDProofTypeException;
import com.cognizant.exception.Only1NomineeAllowedException;
import com.cognizant.service.UserNomineesService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;

import java.time.LocalDate;
import java.util.Arrays;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

 class TestUserNomineesController {
    @BeforeEach
     void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @AfterEach
     void tearDown() throws Exception {

    }

    @Mock
    UserNomineesService userNomineesService;

    @InjectMocks
    UserNomineesController userNomineesController;

     @Test
    void testAddUserNomineeForUser_Positive() {
        try {
            UserNomineesDTO userNomineesDTO = new UserNomineesDTO();
            userNomineesDTO.setFullName("Paul Antony");
            userNomineesDTO.setGender('M');
            userNomineesDTO.setIdProofType("Passport");
            userNomineesDTO.setIdProofDocNumber("12345");
            userNomineesDTO.setNationality("Indian");

            when(userNomineesService.addNomineeDetails(userNomineesDTO, "abanto1234")).thenReturn("success");

            ResponseEntity<?> response = userNomineesController.addNomineeForUser("abanto1234", userNomineesDTO);

            assertEquals(HttpStatus.OK, response.getStatusCode());

        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);

        }


    }

    @Test
    void testAddUserNomineeForUser_Negative() {
        try {
            UserNomineesDTO userNomineesDTO = new UserNomineesDTO();
            userNomineesDTO.setFullName("Paul Antony");
            userNomineesDTO.setGender('M');
            userNomineesDTO.setIdProofType("Passport");
            userNomineesDTO.setIdProofDocNumber("12345");
            userNomineesDTO.setNationality("Indian");

            when(userNomineesService.addNomineeDetails(userNomineesDTO, "abanto1234")).thenReturn("failure");

            ResponseEntity<?> response = userNomineesController.addNomineeForUser("abanto1234", userNomineesDTO);

            assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());

        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);

        }


    }


    @Test
    void testAddUserNomineeForUser_IdProofException() {
        try {
            UserNomineesDTO userNomineesDTO = new UserNomineesDTO();
            userNomineesDTO.setFullName("Paul Antony");
            userNomineesDTO.setGender('M');
            userNomineesDTO.setIdProofType("Passport");
            userNomineesDTO.setIdProofDocNumber("12345");
            userNomineesDTO.setNationality("India");

            when(userNomineesService.addNomineeDetails(userNomineesDTO, "abanto1234")).thenThrow(IDProofTypeException.class);

            ResponseEntity<?> response = userNomineesController.addNomineeForUser("abanto1234", userNomineesDTO);

            assertEquals(HttpStatus.NOT_ACCEPTABLE, response.getStatusCode());

        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(true);

        }


    }

    @Test
    void testAddUserNomineeForUser_Only1NomineeExcpetion() {
        try {
            UserNomineesDTO userNomineesDTO = new UserNomineesDTO();
            userNomineesDTO.setFullName("Paul Antony");
            userNomineesDTO.setGender('M');
            userNomineesDTO.setIdProofType("Passport");
            userNomineesDTO.setIdProofDocNumber("12345");
            userNomineesDTO.setNationality("India");

            when(userNomineesService.addNomineeDetails(userNomineesDTO, "abanto1234")).thenThrow(Only1NomineeAllowedException.class);

            ResponseEntity<?> response = userNomineesController.addNomineeForUser("abanto1234", userNomineesDTO);

            assertEquals(HttpStatus.NOT_ACCEPTABLE, response.getStatusCode());

        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(true);

        }


    }

    @Test
    void testDeleteNomineeForUser_Success()  {
        when(userNomineesService.removeNomineeDetails(anyString())).thenReturn("success");

        ResponseEntity<?> response = userNomineesController.deleteNomineeForUser("abanto1234");

        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    void testDeleteNomineeForUser_Failure()  {
        when(userNomineesService.removeNomineeDetails(anyString())).thenReturn("failure");

        ResponseEntity<?> response = userNomineesController.deleteNomineeForUser("abanto1234");

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }



    @Test
    void testGetNomineeForUser_Success() {
        try {
            UserNomineesDTO userNomineesDTO = Mockito.mock(UserNomineesDTO.class);
            userNomineesDTO.setFullName("Paul Antony");
            userNomineesDTO.setGender('M');
            userNomineesDTO.setIdProofType("Passport");
            userNomineesDTO.setIdProofDocNumber("12345");
            userNomineesDTO.setNationality("Indian");


            when(userNomineesService.getNomineeDetails(anyString())).thenReturn(userNomineesDTO);
            when(userNomineesDTO.getFullName()).thenReturn("Paul Antony");

            ResponseEntity<?> response = userNomineesController.getNomineeForUser("abanto1234");

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals(userNomineesDTO, response.getBody());
        }

    catch(Exception e)
    {
        e.printStackTrace();
        assertTrue(false);
    }

}

    @Test
    void testGetNomineeForUser_Failure() {
        try {
            UserNomineesDTO userNomineesDTO = Mockito.mock(UserNomineesDTO.class);
            userNomineesDTO.setFullName(null);
            userNomineesDTO.setGender('M');
            userNomineesDTO.setIdProofType("Passport");
            userNomineesDTO.setIdProofDocNumber("12345");
            userNomineesDTO.setNationality("Indian");


            when(userNomineesService.getNomineeDetails(anyString())).thenReturn(userNomineesDTO);


            ResponseEntity<?> response = userNomineesController.getNomineeForUser("abanto1234");

            assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());

        }

        catch(Exception e)
        {
            e.printStackTrace();
            assertTrue(false);
        }

    }


    @Test
    void testHandleValidationExceptions() {
        MethodArgumentNotValidException ex = mock(MethodArgumentNotValidException.class);
        BindingResult bindingResult = mock(BindingResult.class);
        ObjectError objectError1 = new FieldError("object", "field", "defaultMessage1");
        ObjectError objectError2 = new FieldError("object", "field", "defaultMessage2");
        when(ex.getBindingResult()).thenReturn(bindingResult);
        when(bindingResult.getAllErrors()).thenReturn(Arrays.asList(objectError1, objectError2));
        ResponseEntity<?> result = userNomineesController.handleValidationExceptions(ex);
        assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
        assertEquals("defaultMessage1", result.getBody());
    }
}






