package com.cognizant.main.ControllerTest;

import com.cognizant.controller.NomineeRelationsController;
import com.cognizant.dto.NomineeRelationsDTO;
import com.cognizant.service.NomineeRelationsService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class TestNomineeRelationsController {
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @AfterEach
    void tearDown() throws Exception {

    }

    @Mock
    NomineeRelationsService nomineeRelationsService;

    @InjectMocks
    NomineeRelationsController nomineeRelationsController;

    @Test
     void testFetchAllNomineeType()
    {
        List<NomineeRelationsDTO> mockNomineeTypes = new ArrayList<>();
        NomineeRelationsDTO nomineeRelationsDTO = new NomineeRelationsDTO();
        nomineeRelationsDTO.setNomineeRelationType(NomineeRelationsDTO.NomineeRelationType.Spouse);
        mockNomineeTypes.add(nomineeRelationsDTO);
        when(nomineeRelationsService.getAllNomineeTypes()).thenReturn(mockNomineeTypes);

        ResponseEntity<?> response = nomineeRelationsController.fetchAllNomineeType();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(mockNomineeTypes, response.getBody());
    }


    @Test
    void testHandleValidationExceptions() {
        MethodArgumentNotValidException ex = mock(MethodArgumentNotValidException.class);
        BindingResult bindingResult = mock(BindingResult.class);
        ObjectError objectError1 = new FieldError("object", "field", "defaultMessage1");
        ObjectError objectError2 = new FieldError("object", "field", "defaultMessage2");
        when(ex.getBindingResult()).thenReturn(bindingResult);
        when(bindingResult.getAllErrors()).thenReturn(Arrays.asList(objectError1, objectError2));
        ResponseEntity<?> result = nomineeRelationsController.handleValidationExceptions(ex);
        assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
        assertEquals("defaultMessage1",  result.getBody());
    }
}



