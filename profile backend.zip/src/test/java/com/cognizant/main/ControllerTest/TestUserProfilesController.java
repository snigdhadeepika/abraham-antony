package com.cognizant.main.ControllerTest;

import com.cognizant.controller.UserProfilesController;
import com.cognizant.dto.UserProfilesDTO;
import com.cognizant.exception.IDProofTypeException;
import com.cognizant.service.UserProfilesService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;

import java.time.LocalDate;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class TestUserProfilesController {
    @BeforeEach
     void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @AfterEach
    void tearDown() throws Exception {

    }

    @Mock
    UserProfilesService userProfilesService;

    @InjectMocks
    UserProfilesController userProfilesController;


    @Test
    void testAddNewUserProfiles_Positive() {
        try {
            UserProfilesDTO userProfilesDTO = new UserProfilesDTO();
            userProfilesDTO.setFirstName("Abraham");
            userProfilesDTO.setMiddleName("k");
            userProfilesDTO.setLastName("antony");
            userProfilesDTO.setDateOfBirth(LocalDate.now());
            userProfilesDTO.setGender('M');
            userProfilesDTO.setProfession("SDE");
            userProfilesDTO.setCurrentAddress("Pune");
            userProfilesDTO.setNationality("Indian");
            userProfilesDTO.setIdProofType("Passport");
            userProfilesDTO.setIdProofDocNumber("3231");
            userProfilesDTO.setPhoneNumber("1234567890");
            userProfilesDTO.setEmailAddress("abru@123");

            when(userProfilesService.addUserProfile(userProfilesDTO)).thenReturn("abanto1234");


            ResponseEntity<?> response = userProfilesController.addNewUserProfile(userProfilesDTO);
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals("abanto1234", response.getBody());
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }



        @Test
         void testAddNewUserProfiles_Negative()
        {
            try{
                UserProfilesDTO userProfilesDTO = new UserProfilesDTO();
                userProfilesDTO.setFirstName("Abraham");
                userProfilesDTO.setMiddleName("k");
                userProfilesDTO.setLastName("antony");
                userProfilesDTO.setDateOfBirth(LocalDate.now());
                userProfilesDTO.setGender('M');
                userProfilesDTO.setProfession("SDE");
                userProfilesDTO.setCurrentAddress("Pune");
                userProfilesDTO.setNationality("India");
                userProfilesDTO.setIdProofType("Passport");
                userProfilesDTO.setIdProofDocNumber("3231");
                userProfilesDTO.setPhoneNumber("1234567890");
                userProfilesDTO.setEmailAddress("abru@123");

                when(userProfilesService.addUserProfile(userProfilesDTO)).thenThrow(IDProofTypeException.class);


                ResponseEntity<?> response = userProfilesController.addNewUserProfile(userProfilesDTO);
                assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());

            }
            catch(Exception e) {
                e.printStackTrace();
                assertTrue(true);
            }
}


    @Test
    void testHandleValidationExceptions() {
        MethodArgumentNotValidException ex = mock(MethodArgumentNotValidException.class);
        BindingResult bindingResult = mock(BindingResult.class);
        ObjectError objectError1 = new FieldError("object", "field", "defaultMessage1");
        ObjectError objectError2 = new FieldError("object", "field", "defaultMessage2");
        when(ex.getBindingResult()).thenReturn(bindingResult);
        when(bindingResult.getAllErrors()).thenReturn(Arrays.asList(objectError1, objectError2));
        ResponseEntity<?> result = userProfilesController.handleValidationExceptions(ex);
        assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
        assertEquals("defaultMessage1", result.getBody());
    }







    }

