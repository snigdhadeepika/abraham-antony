package com.cognizant.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.cognizant.ProfileManagementApplication;

import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest(classes =ProfileManagementApplication.class )
class ProfileManagementApplicationTests {

	@Test
	void contextLoads() {

		assertTrue(true);
	}

}
