package com.cognizant.validate;

import java.time.LocalDate;
import java.time.Period;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class DateOfBirthValidator implements ConstraintValidator<DateOfBirthValidate,LocalDate>{



	@Override
	public boolean isValid(LocalDate value, ConstraintValidatorContext context) {
		
		
			Period period = value.until(LocalDate.now());
			  int yearsBetween = period.getYears();
			  if(yearsBetween>=18)
			  {
				  return true;
			  }
			  else
			  {
				  return false;
			  }
	}

}
