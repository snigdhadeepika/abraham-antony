package com.cognizant.validate;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;



public class GenderValidator implements ConstraintValidator<GenderValidate, Character> {

    @Override
    public boolean isValid(Character value, ConstraintValidatorContext context) {
        if (value == 'M' || value == 'F' || value == 'O') {
            return true;
        } else {
            return false;
        }
    }
}
