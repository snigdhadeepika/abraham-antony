package com.cognizant.validate;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.*;

@Target({ElementType.FIELD,ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Constraint(validatedBy = GenderValidator.class)
public @interface GenderValidate {
    public String message() default "Gender must be M,F or O ";
    Class<?>[] groups() default{};

    Class<? extends Payload>[] payload() default{};
}
