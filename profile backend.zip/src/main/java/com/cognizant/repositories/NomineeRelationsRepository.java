package com.cognizant.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.cognizant.entity.NomineeRelations;

@Repository
public interface NomineeRelationsRepository extends JpaRepository<NomineeRelations,Integer> {
    NomineeRelations findByType(int type);

}
