package com.cognizant.repositories;

import com.cognizant.entity.NomineeRelations;
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.cognizant.entity.UserNominees;
import com.cognizant.entity.UserProfiles;

@Repository
public interface UserNomineesRepository extends JpaRepository<UserNominees,Integer> {
	


	  public UserNominees findByUserProfiles(UserProfiles userProfiles);
	  public UserNominees findByNomineeRelations(NomineeRelations nomineeRelations);



	
	
	
	

}
