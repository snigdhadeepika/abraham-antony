package com.cognizant.utilities;

import java.security.SecureRandom;

public class UserNameGenerator {
    public static String userNameGenerator(String firstName, String lastName) {
        final String userName = "";
        String firstTwoLetters = firstName.substring(0, Math.min(firstName.length(), 2)).toLowerCase();

        if (firstTwoLetters.length() < 2) {
            do {
                firstTwoLetters = firstTwoLetters + "_";
            } while (firstTwoLetters.length() < 2);

        }

        String lastFourLetters = lastName.substring(0, Math.min(firstName.length(), 4)).toLowerCase();

        if (lastFourLetters.length() < 4) {
            do {
                lastFourLetters = lastFourLetters + "_";
            } while (lastFourLetters.length() < 4);

        }
        SecureRandom secureRandom = new SecureRandom();
        int serialNumber= secureRandom.nextInt(9000) + 1000;

        return userName + firstTwoLetters + lastFourLetters + serialNumber;

    }
}
