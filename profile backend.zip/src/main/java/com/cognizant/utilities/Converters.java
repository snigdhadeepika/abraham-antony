package com.cognizant.utilities;

import com.cognizant.dto.NomineeRelationsDTO;

public class Converters {
    public static int NomineeConverter(NomineeRelationsDTO.NomineeRelationType nomineeRelationType) {
        switch (nomineeRelationType) {
            case Parent:
                return 0;
            case Child:
                return 1;
            case Sibling:
                return 2;
            case Spouse:
                return 3;
            case Cousin:
                return 4;
            default:return -1;
        }
    }

    public static NomineeRelationsDTO.NomineeRelationType IntConverter(int type) {
        switch (type) {
            case 0:
                return NomineeRelationsDTO.NomineeRelationType.Parent;
            case 1:
                return NomineeRelationsDTO.NomineeRelationType.Child;
            case 2:
                return NomineeRelationsDTO.NomineeRelationType.Sibling;
            case 3:
                return NomineeRelationsDTO.NomineeRelationType.Spouse;
            case 4:
                return NomineeRelationsDTO.NomineeRelationType.Cousin;
            default:return null;
        }
    }



}
