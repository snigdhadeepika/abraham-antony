package com.cognizant.service;

import com.cognizant.dto.UserNomineesDTO;
import com.cognizant.entity.UserNominees;
import com.cognizant.entity.UserProfiles;
import com.cognizant.exception.IDProofTypeException;
import com.cognizant.exception.Only1NomineeAllowedException;
import com.cognizant.mappers.UserNomineesMapper;
import com.cognizant.repositories.NomineeRelationsRepository;
import com.cognizant.repositories.UserNomineesRepository;
import com.cognizant.repositories.UserProfilesRepository;
import com.cognizant.utilities.Converters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service

public class UserNomineesServiceImpl implements UserNomineesService {

    private UserNomineesRepository userNomineesRepository;

    private NomineeRelationsRepository nomineeRelationsRepository;


    private UserProfilesRepository userProfilesRepository;


    @Autowired
    public UserNomineesServiceImpl(UserProfilesRepository userProfilesRepository, NomineeRelationsRepository nomineeRelationsRepository, UserNomineesRepository userNomineesRepository) {
        this.userProfilesRepository = userProfilesRepository;
        this.userNomineesRepository = userNomineesRepository;
        this.nomineeRelationsRepository = nomineeRelationsRepository;

    }



    public String removeNomineeDetails(String username) {
        Optional<UserProfiles> userProfilesOptional = userProfilesRepository.findById(username);
        String result = "";
        String result1="failure";
        if (userProfilesOptional.isPresent()) {
            UserNominees userNominees = userNomineesRepository.findByUserProfiles(userProfilesOptional.get());
            int id = userNominees.getId();
            userNomineesRepository.delete(userNominees);

            if (userNomineesRepository.findById(id).isEmpty()) {
                result = result + "success";
            } else {
                result = result + result1;
            }
        } else {
            result += result1;
        }
        return result;

    }


    public String addNomineeDetails(UserNomineesDTO userNomineesDTO, String username) throws Only1NomineeAllowedException, IDProofTypeException {
        String result = "";
        String result1="failure";
        UserNominees userNomineesResult;
        Optional<UserProfiles> userProfilesOptional = userProfilesRepository.findById(username);
        if (!userNomineesDTO.getNationality().equalsIgnoreCase("Indian") && !userNomineesDTO.getIdProofType().equalsIgnoreCase("Passport")) {
            throw new IDProofTypeException("If nationality is other than Indian Passport is only accepted");

        } else {


            if (userProfilesOptional.isPresent()) {

                if (userNomineesRepository.findByUserProfiles(userProfilesOptional.get()) == null) {
                    UserNominees userNominees = UserNomineesMapper.UserNomineesDTOtoEntity(userNomineesDTO);
                    userNominees.setUserProfiles(userProfilesOptional.get());
                    userNominees.setNomineeRelations(nomineeRelationsRepository.findByType(Converters.NomineeConverter(userNomineesDTO.getNomineeRelationType())));
                    userNomineesResult = userNomineesRepository.save(userNominees);
                } else
                {
                    throw new Only1NomineeAllowedException("One user can have only one Nominee");
                }


                if (userNomineesResult.getClass()!= null) {
                    result += "success";
                } else {
                    result += result1;
                }
            } else {
                result += result1;
            }
        }


        return result;
    }


    public UserNomineesDTO getNomineeDetails(String username) {
        Optional<UserProfiles> userProfilesOptional = userProfilesRepository.findById(username);
        UserNomineesDTO userNomineesDTO ;
        if (userProfilesOptional.isPresent()) {

            UserNominees userNominees = userNomineesRepository.findByUserProfiles(userProfilesOptional.get());
            if(userNominees.getClass()!=null) {
                userNomineesDTO = UserNomineesMapper.UserNomineesEntitytoDTO(userNominees);
                userNomineesDTO.setNomineeRelationType(Converters.IntConverter(userNominees.getNomineeRelations().getType()));
            }
            else {
                userNomineesDTO=null;
            }

        } else {
            userNomineesDTO = null;

        }
        return userNomineesDTO;
    }

}
