package com.cognizant.service;

import com.cognizant.dto.UserProfilesDTO;

import com.cognizant.exception.IDProofTypeException;



public interface UserProfilesService {
	
	public String addUserProfile(UserProfilesDTO userProfilesDTO) throws IDProofTypeException ;

}
