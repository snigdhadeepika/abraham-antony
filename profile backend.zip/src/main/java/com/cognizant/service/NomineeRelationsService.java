package com.cognizant.service;

import java.util.List;

import com.cognizant.dto.NomineeRelationsDTO;



public interface NomineeRelationsService{
	public List<NomineeRelationsDTO> getAllNomineeTypes();
	
	
	
}