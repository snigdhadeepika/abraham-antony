package com.cognizant.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


import com.cognizant.mappers.NomineeRelationsMapper;

import org.springframework.beans.factory.annotation.Autowired;

import com.cognizant.dto.NomineeRelationsDTO;
import com.cognizant.entity.NomineeRelations;
import com.cognizant.repositories.NomineeRelationsRepository;
import org.springframework.stereotype.Service;



@Service
public class NomineeRelationsServiceImpl implements NomineeRelationsService {


    NomineeRelationsRepository nomineeRelationsRepository;


    @Autowired
    NomineeRelationsServiceImpl(NomineeRelationsRepository nomineeRelationsRepository)
    {

        this.nomineeRelationsRepository=nomineeRelationsRepository;
    }

    public List<NomineeRelationsDTO> getAllNomineeTypes() {
        Iterable<NomineeRelations> nomineeRelationsIterable=nomineeRelationsRepository.findAll();
        Iterator<NomineeRelations> nomineeRelationsIterator=nomineeRelationsIterable.iterator();
        List<NomineeRelationsDTO> nomineeRelationsDTOList=new ArrayList<>();

        while(nomineeRelationsIterator.hasNext())
        {

            nomineeRelationsDTOList.add(NomineeRelationsMapper.NomineeRelationEntitytoDTO(nomineeRelationsIterator.next()));
        }

        return nomineeRelationsDTOList;

    }





}
