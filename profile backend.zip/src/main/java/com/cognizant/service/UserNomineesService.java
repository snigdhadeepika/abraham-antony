package com.cognizant.service;

import com.cognizant.dto.UserNomineesDTO;

import com.cognizant.exception.IDProofTypeException;
import com.cognizant.exception.Only1NomineeAllowedException;




public interface UserNomineesService {
	
	public String removeNomineeDetails(String userName);
	
	public String addNomineeDetails(UserNomineesDTO userNomineesDTO,String userName) throws Only1NomineeAllowedException,IDProofTypeException;
	
	public UserNomineesDTO getNomineeDetails(String userName);

}
