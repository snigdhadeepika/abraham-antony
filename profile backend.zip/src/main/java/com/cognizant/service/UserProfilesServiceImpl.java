package com.cognizant.service;

import com.cognizant.mappers.UserProfilesMapper;
import com.cognizant.exception.IDProofTypeException;
import org.springframework.beans.factory.annotation.Autowired;

import com.cognizant.dto.UserProfilesDTO;
import com.cognizant.entity.UserProfiles;
import com.cognizant.repositories.UserProfilesRepository;
import org.springframework.stereotype.Service;



@Service
public class UserProfilesServiceImpl implements UserProfilesService{

	private UserProfilesRepository userProfilesRepository;



	@Autowired
	public UserProfilesServiceImpl(UserProfilesRepository userProfilesRepository) {
		this.userProfilesRepository = userProfilesRepository;
	}


	public String addUserProfile(UserProfilesDTO userProfilesDTO)  throws IDProofTypeException {
		String userName;
		if(!userProfilesDTO.getNationality().equalsIgnoreCase("Indian")&&!userProfilesDTO.getIdProofType().equalsIgnoreCase("Passport"))
		{
			throw new IDProofTypeException("If nationality is other than Indian Passport is only accepted");
		}
		else{
			UserProfiles userProfiles = UserProfilesMapper.userProfilesDTOtoEntity(userProfilesDTO);


			userName = userProfilesRepository.save(userProfiles).getUsername();

		}

      return userName;

	}
	}



