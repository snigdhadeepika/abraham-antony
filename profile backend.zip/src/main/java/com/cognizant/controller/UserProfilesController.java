package com.cognizant.controller;

import com.cognizant.dto.UserProfilesDTO;
import com.cognizant.exception.IDProofTypeException;
import com.cognizant.service.UserProfilesService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@Slf4j
@CrossOrigin("http://localhost:4200/")
public class UserProfilesController {
    private UserProfilesService userProfilesService;
    @Autowired
            public UserProfilesController(UserProfilesService userProfilesService) {
        this.userProfilesService= userProfilesService;
    }
     @Operation
    @PostMapping("/profile")
    public ResponseEntity<String> addNewUserProfile(@Valid @RequestBody UserProfilesDTO userProfilesDTO)
    {
        log.info("User Profiles addNewUserProfile logged");
        try {
            String username = userProfilesService.addUserProfile(userProfilesDTO);
            return new ResponseEntity<>(username, HttpStatus.OK);
        }catch (IDProofTypeException e)
        {
            return new ResponseEntity<>(e.getMessage(),HttpStatus.BAD_REQUEST);
        }
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<String> handleValidationExceptions(MethodArgumentNotValidException ex) {
        BindingResult bindingResult = ex.getBindingResult();
        List<String> errorMessages = bindingResult.getAllErrors().stream()
                .map(DefaultMessageSourceResolvable::getDefaultMessage)
                .toList();
        return new ResponseEntity<>(errorMessages.get(0), HttpStatus.BAD_REQUEST);
    }



}
