package com.cognizant.controller;

import com.cognizant.dto.UserNomineesDTO;
import com.cognizant.exception.IDProofTypeException;
import com.cognizant.exception.Only1NomineeAllowedException;
import com.cognizant.service.UserNomineesService;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;

import lombok.extern.slf4j.Slf4j;
import org.springdoc.api.ErrorMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@Slf4j
@RequestMapping("/api/profile")
@CrossOrigin("http://localhost:4200/")

public class UserNomineesController {

    private UserNomineesService userNomineesService;
@Autowired
        public UserNomineesController (UserNomineesService userNomineesService){
    this.userNomineesService=userNomineesService;
}

        @Operation
        @PostMapping("/{username}/nominee")
        public ResponseEntity<String> addNomineeForUser(@PathVariable String username, @Valid@RequestBody UserNomineesDTO userNomineesDTO)
        {
            log.info("User Nominees addNomineeForUser logged");
            String result;
            try {
                result = userNomineesService.addNomineeDetails(userNomineesDTO, username);


                if (result.equalsIgnoreCase("success")) {
                    return new ResponseEntity<>(result,HttpStatus.OK);
                } else {
                    return new ResponseEntity<>(result,HttpStatus.BAD_REQUEST);
                }
            }
            catch(Only1NomineeAllowedException | IDProofTypeException e)
            {
                return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_ACCEPTABLE);
            }


        }

        @Operation
        @DeleteMapping("/{username}/nominee")
        public ResponseEntity<String> deleteNomineeForUser(@PathVariable String username)
        {
            log.info("User Nominees deleteNomineeForUser logged");
            String result= userNomineesService.removeNomineeDetails(username);
            if(result.equalsIgnoreCase("success") ){
                return new ResponseEntity<>(result,HttpStatus.OK);
            }else
            {
                return new ResponseEntity<>(result,HttpStatus.BAD_REQUEST);
            }
        }

        @Operation
        @GetMapping("/{username}/nominee")
        public ResponseEntity<UserNomineesDTO> getNomineeForUser(@PathVariable String username)
        {
            log.info("User Nominees getNomineeForUser logged");
            UserNomineesDTO userNomineesDTO=userNomineesService.getNomineeDetails(username);
            if(userNomineesDTO.getFullName()!=null)
            {
                return new ResponseEntity<>(userNomineesDTO,HttpStatus.OK);
            }
            else
            {
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            }
        }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<String> handleValidationExceptions(MethodArgumentNotValidException ex) {
        BindingResult bindingResult = ex.getBindingResult();
        List<String> errorMessages = bindingResult.getAllErrors().stream()
                .map(DefaultMessageSourceResolvable::getDefaultMessage)
                .toList();
        return new ResponseEntity<>(errorMessages.get(0), HttpStatus.BAD_REQUEST);
    }

    
}
