package com.cognizant.controller;

import com.cognizant.dto.NomineeRelationsDTO;

import org.springdoc.api.ErrorMessage;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import com.cognizant.service.NomineeRelationsService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@Slf4j
@RequestMapping("/api")
@CrossOrigin("http://localhost:4200/")
public class NomineeRelationsController {

    private NomineeRelationsService nomineeRelationsService;


    @Autowired
    public NomineeRelationsController(NomineeRelationsService nomineeRelationsService)
    {
        this.nomineeRelationsService = nomineeRelationsService;
    }

    @Operation
    @GetMapping("/nomineetypesjj")

    public ResponseEntity<List<NomineeRelationsDTO>> fetchAllNomineeType()
    {
        log.info("Authentication Controller logged");
       return new ResponseEntity<>(nomineeRelationsService.getAllNomineeTypes(),HttpStatus.OK);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<String> handleValidationExceptions(MethodArgumentNotValidException ex) {
        BindingResult bindingResult = ex.getBindingResult();
        List<String> errorMessages = bindingResult.getAllErrors().stream()
                .map(DefaultMessageSourceResolvable::getDefaultMessage)
                .toList();
        return new ResponseEntity<>(errorMessages.get(0), HttpStatus.BAD_REQUEST);
    }

}



