package com.cognizant.authentication;

import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class UserServiceImpl implements UserService{

    UsersRepository usersRepository;

    UserServiceImpl(UsersRepository usersRepository)
    {
        this.usersRepository = usersRepository;
    }

    public UsersDTO authenticateUser(String userName, String password) {

        UsersDTO usersDTO = new UsersDTO();
        List<Users> usersList=usersRepository.findAll();
        for(Users user:usersList)
        {
            if(user.getUserName().equals(userName)&&user.getPassword().equals(password)&&!user.isAccountLocked()) {
                usersDTO.setUserName(user.getUserName());
                usersDTO.setPassword(user.getPassword());
                break;
            }
        }
        if(usersDTO.getUserName()!=null)
        {
            usersDTO.setAccountLocked(false);
        }
        else
        {
            usersDTO.setAccountLocked(true);
        }

        return usersDTO;

    }
}
