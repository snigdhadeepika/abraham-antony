package com.cognizant.authentication;

import lombok.Data;

@Data
public class UserRequestDTO {

    private String userName;
    private String password;
}
