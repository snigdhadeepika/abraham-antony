package com.cognizant.authentication;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpStatus;
import org.springdoc.api.ErrorMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;

@RestController
@Slf4j
@RequestMapping("/authenticate")
@CrossOrigin("http://localhost:4200/")
public class AuthenticationController {

    UserService userService;


    @Autowired

    AuthenticationController(UserService userService)
    {
        this.userService = userService;
    }
    @PostMapping("/users")
    public ResponseEntity<?> authenticate(@Valid @RequestBody UserRequestDTO userRequestDTO)
    {

        UsersDTO usersDTO1 = new UsersDTO();

        usersDTO1 = userService.authenticateUser(userRequestDTO.getUserName(),userRequestDTO.getPassword());

        log.info("Authentication Controller authenticate logged");
       return new ResponseEntity<UsersDTO>(usersDTO1, HttpStatusCode.valueOf(HttpStatus.SC_ACCEPTED));
    }


}
