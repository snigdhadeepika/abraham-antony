package com.cognizant.authentication;

import com.cognizant.authentication.UsersDTO;

public interface UserService {

    public UsersDTO authenticateUser(String userName, String password);
}
