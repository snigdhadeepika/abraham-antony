package com.cognizant.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;

import jakarta.persistence.Table;
import jakarta.persistence.Id;

import lombok.*;

@Entity
@Table(name="Nominee_Relations")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class NomineeRelations {
	@Id
	@Column(name="Nominee_Relations_Id")
	private int nomineeRelationsId;
	@Column(name="Type")
	private int type;
	

	

}
