package com.cognizant.entity;

import java.time.LocalDate;

import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="UserProfiles")
public class UserProfiles {
	@Id
	@Column(name="Username")

	private String username;
	
	@Column(name="First_Name")
	private String firstName;
	
	@Column(name="Middle_Name")
	private String middleName;
	
	@Column(name="Last_Name")
	private String lastName;
	
	@Column(name="Date_Of_Birth")
	private LocalDate dateOfBirth;
	
	@Column(name="Gender")
	private char gender;
	
	@Column(name="Profession")
	private String profession;
	
	@Column(name="Current_Address")
	private String currentAddress;
	
	@Column(name="Nationality")
	private String nationality;
	
	@Column(name="ID_Proof_Type")
	private String idProofType;
	
	@Column(name="ID_Proof_Doc_Number")
	private String idProofDocNumber;
	
	@Column(name="Phone_Number")
	private String phoneNumber;
	
	@Column(name="Email_Address")
	private String emailAddress;
	

}
