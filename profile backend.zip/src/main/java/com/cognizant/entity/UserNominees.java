package com.cognizant.entity;



import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Table;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="UserNominees")
public class UserNominees {

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
@Column(name="Id")
private int id;

@Column(name="Full_Name")
private String fullName;

@Column(name="Date_Of_Birth")
private LocalDate dateOfBirth;
 
@Column(name="Gender")
private char gender;

@Column(name="ID_Proof_Type")
private String idProofType;

@Column(name="ID_Proof_Doc_Number")
private String idProofDocNumber;

@Column(name="Nationality")
private String nationality;


@ManyToOne
@JoinColumn(name = "Nominee_Relations_Id")
private NomineeRelations nomineeRelations;
 

@OneToOne
@JoinColumn(name = "Username")
private UserProfiles userProfiles;

}
