package com.cognizant.exception;

public class Only1NomineeAllowedException extends  Exception{
    public Only1NomineeAllowedException(String message) {
        super(message);
    }
}
