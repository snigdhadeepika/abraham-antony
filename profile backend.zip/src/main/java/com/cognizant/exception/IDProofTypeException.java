package com.cognizant.exception;

public class IDProofTypeException extends Exception{
    public IDProofTypeException(String message)
    {
        super(message);
    }
}
