package com.cognizant.mappers;

import com.cognizant.dto.UserNomineesDTO;
import com.cognizant.entity.UserNominees;

public class UserNomineesMapper {
    public static UserNomineesDTO UserNomineesEntitytoDTO(UserNominees userNominees)
    {
        UserNomineesDTO userNomineesDTO = new UserNomineesDTO();
        userNomineesDTO.setFullName(userNominees.getFullName());
        userNomineesDTO.setIdProofType(userNominees.getIdProofType());
        userNomineesDTO.setIdProofDocNumber(userNominees.getIdProofDocNumber());
        userNomineesDTO.setNationality(userNominees.getNationality());
        userNomineesDTO.setGender(userNominees.getGender());
        userNomineesDTO.setDateOfBirth(userNominees.getDateOfBirth());
        return userNomineesDTO;
    }

    public static UserNominees UserNomineesDTOtoEntity (UserNomineesDTO userNomineesDTO)
    {
        UserNominees userNominees = new UserNominees();
        userNominees.setFullName(userNomineesDTO.getFullName());
        userNominees.setIdProofDocNumber(userNomineesDTO.getIdProofDocNumber());
        userNominees.setNationality(userNomineesDTO.getNationality());
        userNominees.setIdProofType(userNomineesDTO.getIdProofType());
        userNominees.setGender(userNomineesDTO.getGender());
        userNominees.setDateOfBirth(userNomineesDTO.getDateOfBirth());
        return userNominees;
    }
}
