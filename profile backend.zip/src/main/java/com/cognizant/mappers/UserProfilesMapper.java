package com.cognizant.mappers;

import com.cognizant.dto.UserProfilesDTO;
import com.cognizant.entity.UserProfiles;

import com.cognizant.utilities.UserNameGenerator;

public class UserProfilesMapper {
    public static UserProfiles userProfilesDTOtoEntity(UserProfilesDTO userProfilesDTO)
    {
        UserProfiles userProfiles = new UserProfiles();
        userProfiles.setUsername(UserNameGenerator.userNameGenerator(userProfilesDTO.getFirstName(),userProfilesDTO.getLastName()));
        userProfiles.setGender(userProfilesDTO.getGender());
        userProfiles.setFirstName(userProfilesDTO.getFirstName());
        userProfiles.setMiddleName(userProfilesDTO.getMiddleName());
        userProfiles.setLastName(userProfilesDTO.getLastName());
        userProfiles.setEmailAddress(userProfilesDTO.getEmailAddress());
        userProfiles.setIdProofType(userProfilesDTO.getIdProofType());
        userProfiles.setIdProofDocNumber(userProfilesDTO.getIdProofDocNumber());
        userProfiles.setPhoneNumber(userProfilesDTO.getPhoneNumber());
        userProfiles.setNationality(userProfilesDTO.getNationality());
        userProfiles.setDateOfBirth(userProfilesDTO.getDateOfBirth());
        userProfiles.setProfession(userProfilesDTO.getProfession());
        userProfiles.setCurrentAddress(userProfilesDTO.getCurrentAddress());
        return userProfiles;
    }
}
