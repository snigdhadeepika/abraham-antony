package com.cognizant.mappers;

import com.cognizant.dto.NomineeRelationsDTO;
import com.cognizant.entity.NomineeRelations;
import com.cognizant.utilities.Converters;

public class NomineeRelationsMapper {
    public static NomineeRelationsDTO NomineeRelationEntitytoDTO(NomineeRelations nomineeRelations)
    {
        NomineeRelationsDTO nomineeRelationsDTO = new NomineeRelationsDTO();
        nomineeRelationsDTO.setNomineeRelationType(Converters.IntConverter(nomineeRelations.getType()));
        return nomineeRelationsDTO;
    }
}
