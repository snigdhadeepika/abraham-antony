package com.cognizant.dto;

import java.time.LocalDate;


import com.cognizant.validate.DateOfBirthValidate;
import com.cognizant.validate.GenderValidate;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserNomineesDTO {


	@NotNull(message = "The field should not be null.Enter the value!")
	private String fullName;

	@NotNull(message = "The field should not be null.Enter the value!")@DateOfBirthValidate
	private LocalDate dateOfBirth;



	@NotNull(message = "The field should not be null.Enter the value!") @GenderValidate
	private char gender;

	@Pattern(regexp = "^(?i)(Passport|Aadhar|PAN|DrivingLicense)$",message="IDProofType must be valid")@NotNull(message = "The field should not be null.Enter the value!")
	private String idProofType;
	@NotNull(message = "The field should not be null.Enter the value!")
	private String idProofDocNumber;

	@NotNull(message = "The field should not be null.Enter the value!")
	private String nationality;
	@NotNull(message = "The field should not be null.Enter the value!")
	private NomineeRelationsDTO.NomineeRelationType nomineeRelationType;





}
