package com.cognizant.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import static com.cognizant.dto.NomineeRelationsDTO.NomineeRelationType.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NomineeRelationsDTO {


	private NomineeRelationType nomineeRelationType;


	public enum NomineeRelationType {
		Parent, Child, Sibling, Spouse, Cousin;
	}
}







	


