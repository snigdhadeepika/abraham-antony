package com.cognizant.dto;

import java.time.LocalDate;

import com.cognizant.validate.DateOfBirthValidate;
import com.cognizant.validate.GenderValidate;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserProfilesDTO {

	@Size(min = 10, max = 10, message="Username should have length of 10 ")

	private String username;
	@NotNull(message = "The field should not be null.Enter the value!")
	private String firstName;

	private String middleName;
	@NotNull(message = "The field should not be null.Enter the value!")
	private String lastName;

	@NotNull(message = "The field should not be null.Enter the value!") @DateOfBirthValidate
	private LocalDate dateOfBirth;

	@NotNull(message = "The field should not be null.Enter the value!") @GenderValidate
	private char gender;
	@NotNull(message = "The field should not be null.Enter the value!")
	private String profession;
	@NotNull(message = "The field should not be null.Enter the value!")
	private String currentAddress;
	@NotNull(message = "The field should not be null.Enter the value!")
	private String nationality;

	@NotNull(message = "The field should not be null.Enter the value!") @Pattern(regexp = "^(?i)(Passport|Aadhar|PAN|DrivingLicense)$",message="ID proof Type must be valid")
	private String idProofType;
	@NotNull(message = "The field should not be null.Enter the value!")
	private String idProofDocNumber;
	@NotNull(message = "The field should not be null.Enter the value!")
	private String phoneNumber;
	@NotNull(message = "The field should not be null.Enter the value!")
	private String emailAddress;
	





}
