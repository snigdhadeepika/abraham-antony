insert into Nominee_Relations(Nominee_Relations_Id,Type)
values
(1,0),
(2,1),
(3,2),
(4,3),
(5,4);


insert into Users(user_name,password,is_Account_Locked)
values
('admin','123456789',false),
('user','987654321',false);

