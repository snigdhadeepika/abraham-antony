import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../services/authentication.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {
  
  loggedin:boolean=false;

  constructor(private authService: AuthenticationService,private router:Router){
    
    this.loggedin=authService.isUserLoggedIn();
  
  }


  logOut(){

    this.authService.logOut();
    this.router.navigate(['/login']);


}
}