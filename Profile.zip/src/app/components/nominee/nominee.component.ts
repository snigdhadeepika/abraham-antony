import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl,Validators } from '@angular/forms';
import { UserNominees } from '../../models/UserNominees';
import { UserNomineesService } from '../../services/UserNominees-service';

@Component({
  selector: 'app-nominee',
  templateUrl: './nominee.component.html',
  styleUrl: './nominee.component.css'
})
export class NomineeComponent implements OnInit{
  nomineeForm!:FormGroup;
  userNominees!:UserNominees
  userName!:String
  userNomineesNull!:UserNominees
  showTable: boolean=false;
  showButton: boolean=false;


  constructor(private userNomineesService:UserNomineesService){}

  ngOnInit(){
    this.nomineeForm=new FormGroup({
      'userName': new FormControl(null,[Validators.required,Validators.minLength(10),Validators.maxLength(10)])});
  }
  toggleTable(){
    this.showTable=true;
  }


  OnSearch(){
    console.log("Form Submitted")

     const values=this.nomineeForm.value
     this.userName=values.userName
    this.showTable=true;
    this.showButton=true;

    
    this.userNomineesService.getUserNomineesDetails(values.userName).subscribe(responseData=>{
      this.userNominees=responseData
    })

 
  }

  
  OnDelete()
  {
    this.userNomineesService.deleteUserNomineesDetails(this.userName).subscribe(responseData=>{
      let result=responseData
    })
    this.showTable=false
    this.showButton=false
    this.userNominees=this.userNomineesNull

  }


}