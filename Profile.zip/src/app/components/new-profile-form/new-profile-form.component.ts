import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { UserProfilesService } from '../../services/UserProfiles-service';

@Component({
  selector: 'app-new-profile-form',
  templateUrl: './new-profile-form.component.html',
  styleUrl: './new-profile-form.component.css'
})
export class NewProfileFormComponent implements OnInit{


  newProfileForm!:FormGroup;
  userName!:String
  eighteenYearsAgo!: Date;
  constructor(private userProfileService:UserProfilesService){

  } 

  ngOnInit(){
    this.eighteenYearsAgo = new Date();
    this.eighteenYearsAgo.setFullYear(this.eighteenYearsAgo.getFullYear() - 18);
      this.newProfileForm=new FormGroup({
        'firstName':new FormControl(null,[Validators.required,Validators.pattern("^[a-zA-Z]+$")]),
        'middleName':new FormControl(null,Validators.pattern("^[a-zA-Z]+$")),
        'lastName':new FormControl(null,[Validators.required,Validators.pattern("^[a-zA-Z]+$")]),
        'dateOfBirth':new FormControl('',[Validators.required]),
        'gender':new FormControl(null,[Validators.required]),
        'profession':new FormControl(null,[Validators.required,Validators.pattern("^[a-zA-Z]+$")]),
        'currentAddress':new FormControl(null,[Validators.required]),
        'nationality':new FormControl(null,[Validators.required]),
        'idProofType':new FormControl(null,[Validators.required]), 
        'idProofDocNumber':new FormControl(null,[Validators.required]),
        'phoneNumber':new FormControl(null,[Validators.required,Validators.pattern("^\\d{10}$")]),
        'emailAddress':new FormControl(null,[Validators.required ,Validators.pattern("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$")])})
        
  
      function dateOfBirthValidator(): ValidatorFn {
        return (control: AbstractControl):ValidationErrors | null => {
          const forbidden = checkIfUnderEighteen({ dateOfBirth: control.value });
          return forbidden ? {'dateOfBirthInvalid': {value: control.value}} : null;
        };
      }
      
      function checkIfUnderEighteen(dateOfBirth:Date|any ):Boolean|any {
      
        const today = new Date();
        const birthDate = new Date(dateOfBirth);
        let age = today.getFullYear() - birthDate.getFullYear();
        const m = today.getMonth() - birthDate.getMonth();
      
        if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
          age--;
        }else{
      
        if(age < 18)
        {
           return false
        }
        else
        {
          return true
        }
        }
      }
    
  }

  scrollToTop()
  {
    window.scrollTo({
      top:0,
      behavior:'smooth'
    })
  }

   onSubmit(): void {
    console.log(this.newProfileForm);
    this.userProfileService.addNewUserProfiles(this.newProfileForm.value).subscribe({
        next: (responseData) => {
            this.userName = responseData;
            this.newProfileForm.reset();
        },
        error: err => {
          let notificationBar = document.getElementById('notification-bar');
      if (notificationBar !== null) {
        let errorMessage = err.error;
        notificationBar.innerHTML = `<div class="alert alert-danger" role="alert">${errorMessage}</div>`;
        setTimeout(() => {
          if (notificationBar !== null) {
            notificationBar.innerHTML = '';
          }
        }, 10000);
      }
          
        }
    });
   this.scrollToTop();
}
}
