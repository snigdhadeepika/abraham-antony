import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { NomineeRelations } from '../../models/NomineeRelations';
import { UserNomineesService } from '../../services/UserNominees-service';

@Component({
  selector: 'app-add-nominee-form',
  templateUrl: './add-nominee-form.component.html',
  styleUrl: './add-nominee-form.component.css'
})
export class AddNomineeFormComponent implements OnInit{

  addNomineeForm!:FormGroup;
  result!:string;

  constructor(private http:HttpClient,private userNomineesService: UserNomineesService){}

  ngOnInit() {
       this.addNomineeForm=new FormGroup({
      'userName': new FormControl(null,[Validators.required,Validators.pattern("^.{10}$")]),
      'fullName':new FormControl(null,[Validators.required,Validators.pattern("^[A-Za-z ]*$")]),
      'dateOfBirth':new FormControl(null,[Validators.required]),
      'gender':new FormControl(null,[Validators.required]),
      'nationality':new FormControl(null,[Validators.required]),
      'idProofType':new FormControl(null,[Validators.required]),
      'idProofDocNumber':new FormControl(null,[Validators.required]),
      'nomineeRelationType':new FormControl(null,[Validators.required])
      
    })

    this.fetchAllNomineeTypes();
  }
  nomineeRelations:NomineeRelations[]=[];
  submitted=false;

  fetchAllNomineeTypes(){
    this.userNomineesService.getAllNomineesRelationsTypes().subscribe(responseData => {
      this.nomineeRelations = responseData;
    })}

    onSubmit() {
      console.log("hi");
      console.log(this.addNomineeForm);
      this.userNomineesService.addNomineeForUser(this.addNomineeForm.value,this.addNomineeForm.value.userName).subscribe({
          next: responseData => {
            this.addNomineeForm.reset();
            this.result = responseData;
            console.log(responseData);
          },
          error: err => {
            let notificationBar = document.getElementById('notification-bar');
        if (notificationBar !== null) {
          let errorMessage = err.error;
          notificationBar.innerHTML = `<div class="alert alert-danger" role="alert">${errorMessage}</div>`;
          setTimeout(() => {
            if (notificationBar !== null) {
              notificationBar.innerHTML = '';
            }
          }, 10000);
        }
            
          }
      });
      this.scrollToTop();
     
  }
  scrollToTop()
  {
    window.scrollTo({
      top:0,
      behavior:'smooth'
    })
  }



    
  }

  


