import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { NomineeRelations } from "../models/NomineeRelations";
import { UserNominees } from "../models/UserNominees";

@Injectable({
    providedIn: 'root'
})
export class UserNomineesService{
    private getNomineeRelationTypesURL = "http://localhost:8088/api/nomineetypesjj";


    constructor(private http:HttpClient){}

    public getAllNomineesRelationsTypes(){
        return this.http.get<NomineeRelations[]>(this.getNomineeRelationTypesURL);
    }

    public addNomineeForUser(userNominees:UserNominees,userName:String)
    {
        let addNomineesForUserURL ="http://localhost:8088/api/profile/"+userName+"/nominee";
        
        return this.http.post<string>(addNomineesForUserURL,userNominees,{responseType:'text' as 'json'});

    }

    public getUserNomineesDetails(userName:String)
    {
        let getUserNomineesDetailsURL="http://localhost:8088/api/profile/"+userName+"/nominee";
        return this.http.get<UserNominees>(getUserNomineesDetailsURL);
    }

    public deleteUserNomineesDetails(userName:String)
    {
        let deleteUserNomineesDetailsURL="http://localhost:8088/api/profile/"+userName+"/nominee";
        
        return this.http.delete<String>(deleteUserNomineesDetailsURL);
    }


}