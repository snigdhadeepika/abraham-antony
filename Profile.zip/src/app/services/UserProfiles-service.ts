import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { UserProfiles } from "../models/UserProfiles";

@Injectable({
    providedIn: 'root'
})
export class UserProfilesService{
    private addNewUserProfile = "http://localhost:8088/api/profile";

    constructor(private http:HttpClient){}

    public addNewUserProfiles(userProfile:UserProfiles){
        return this.http.post<String>(this.addNewUserProfile,userProfile,{responseType:'text' as 'json'});
    }


}