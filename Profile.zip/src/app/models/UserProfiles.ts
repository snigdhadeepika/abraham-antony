export interface UserProfiles{
    firstName:String,
    middleName:String,
    lastName:String,
    dateOfBirth:String,
    gender:String,
    profession:String,
    currentAddress:String,
    nationality:String,
    idProofType:String,
    idProofDocNumber:String,
    phoneNumber:String,
    emailAddress:String,
}