export class User{
    userName!:String;
    password!:String
    isAccountLocked!:boolean
}