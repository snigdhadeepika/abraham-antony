export interface UserNominees{
    fullName: String;
    dateOfBirth:Date;
    gender:String;
    idProofType:String;
    idProofDocNumber:String;
    nationality:String;
    nomineeRelationType:String;

}