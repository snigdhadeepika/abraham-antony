
export interface NomineeRelations
{
    nomineeRelationType:String;

}