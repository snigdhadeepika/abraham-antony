import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddNomineeFormComponent } from './components/add-nominee-form/add-nominee-form.component';
import { LoginComponent } from './components/login/login.component';
import { NewProfileFormComponent } from './components/new-profile-form/new-profile-form.component';
import { NomineeComponent } from './components/nominee/nominee.component';
import { HomeComponent } from './home/home.component';
import { AuthUserService } from './services/auth-user.service';


const routes: Routes = [
  
  {path:'login',component:LoginComponent},
  {path:'home',component:HomeComponent,canActivate:[AuthUserService]},
  {path:'NewProfile',component: NewProfileFormComponent,canActivate:[AuthUserService]},
  {path:'AddNominees',component: AddNomineeFormComponent,canActivate:[AuthUserService]},
  {path:'ViewNominees',component: NomineeComponent,canActivate:[AuthUserService]},
  {path:'',redirectTo:'login',pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
